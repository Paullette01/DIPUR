package edu.upv.poo;

import java.sql.*;

/**
 * Contiene utilerias para trabajar con bases de datos.
 * @author luisroberto
 */
public class DbUtils {
    
    private static final String DB_URL = 
            "jdbc:oracle:thin:@oracleacad.upvictoria.edu.mx:1521:orcl";
    private static final String DB_USERNAME = "c##2030023";
    private static final String DB_PASSWORD = "Al2030023";
    
    /**
     * Obtiene el objeto Connection a base de datos correspondiente a los 
     * parámetros de configuración por default.
     * @return El objeto Connection.
     * @throws SQLException 
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
    }    
}
